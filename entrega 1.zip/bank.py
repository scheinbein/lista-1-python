saudacao = input("Você chega no banco e diz: ").lower().strip()

if saudacao.startswith ('hello'):
    print('$0')
elif saudacao.startswith('h') and saudacao.startswith != ('hello'):
    print('$20')
else: 
    print('$100')
